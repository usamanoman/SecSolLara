<?php

class Reply extends \Eloquent {
	protected $fillable = [];
}