<?php

class Forum extends \Eloquent {
	protected $fillable = [];

	// each bear climbs many trees
	public function topics() {
		return $this->hasMany('Topic');
	}


}