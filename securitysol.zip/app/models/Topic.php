<?php

class Topic extends \Eloquent {
	protected $fillable = [];
}