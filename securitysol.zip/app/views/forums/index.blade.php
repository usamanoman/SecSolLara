@extends('forumlayout.default')



@section('forum')
	@foreach($forums as $forum)
	<tr>
		<td><a href="{{ URL::route('forum.show',array('id'=>$forum->id)) }}">{{ $forum->title }}</a><br><span class="sub_heading"> -- {{ $forum->description }}</span></td>
		<td>230</td>
		<td>150</td>
	</tr>
	@endforeach
@stop