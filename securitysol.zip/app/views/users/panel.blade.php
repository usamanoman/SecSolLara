@extends('layouts.form')


@section('content')
    <h1>Welcome...!</h1>
    
@stop